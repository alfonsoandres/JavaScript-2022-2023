

function validarUsuario() {
    var usuario;
    
     usuario = document.getElementById('cjausuario').value;

     for (let index = 0; index < usuario.length; index++) {
        
    if (!isNaN(usuario) && usuario.charAt(index) == usuario.charAt(index).toLowerCase()){
     
            console.log("si vale el usuario");
        
        }else{
            console.log("VUELVE A INTRODUCIR EL USUARIO");
        }
         
     }
  
   
}
function validarClave() {
    var clave;
    clave = document.getElementById('cjaclave').value;

    for (let i = 0; i < clave.length; i++) {
        
         if (!isNaN(clave.charAt(i)) &&  clave.charAt(i) == clave.charAt(i).toLowerCase() 
         && clave.charAt(i) == clave.charAt(i).toUpperCase()) {
             console.log("si vale la clave")
         }else{
            console.log("no vale la clave")
    
         }
    }
}

function cancelar() {
    alert("Has cancelado");

    var clave;
    clave = document.getElementById('cjaclave').value=" ";
    var usuario;
    
    usuario = document.getElementById('cjausuario').value=" ";

}