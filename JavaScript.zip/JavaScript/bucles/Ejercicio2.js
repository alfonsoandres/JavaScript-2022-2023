var cifra= prompt("EL NUMERO INTRODUCIDO ES:");


document.write(
`<table>
<tr>
  <th>El numero introducido es:`+cifra+`</th>
</tr>
<tr>
<td>La cifra es: `+cifra.length+`</td>
</tr>
</table>`);