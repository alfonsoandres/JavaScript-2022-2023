


function parImpar() {
   
    let numero=document.getElementById('numero').value;

    if (!isNaN(numero)) {
        if(numero%2==0){  
            alert("El número "+numero+" es par");
        }else{
            alert("El número "+numero+" es impar");      
        }
    }else{
        alert("Introduce un numero valido");
    }
}




    