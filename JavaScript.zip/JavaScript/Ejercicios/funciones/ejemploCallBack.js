

var listanumeros=[1,2   ,3,4,5];

var suma =listanumeros.reduce((acu,valor)=>acu+valor,0);


console.log(suma);
