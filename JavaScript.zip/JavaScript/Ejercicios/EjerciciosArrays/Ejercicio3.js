var loteria=new Set([]);
var x = new Set([]);



for (let index = 0; index < 50; index++) {
    
    loteria.add( Math.round(Math.random()*49));
        for (let i = 0; index < 6; index++) {

            x.add(loteria);
        }
}


console.log(x);
