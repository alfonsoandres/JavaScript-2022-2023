let numero = parseInt(prompt("Dime un numero"));


	var total = 1; 
	for (i=1; i<=numero; i++) {
		total = total * i; 
	}

    alert(total);