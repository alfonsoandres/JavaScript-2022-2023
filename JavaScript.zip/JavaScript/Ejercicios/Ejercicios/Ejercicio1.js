let valor1 = prompt("Dame el valor 1",0);

if (!isNaN(valor1)) {
    alert("Es un numero");
  }else{
      alert("No es un numero");
  }