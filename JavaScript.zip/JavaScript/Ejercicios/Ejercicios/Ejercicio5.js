    var lineas=prompt("dime cuntas lineas quieres");

for (var i = 1; i <= lineas; i++)
    {
        var k;
        for (k = i; k < lineas; j++)
        {
        
            document.write(" ");
        }
    }


for (var j = 1; i < i*2-1; i++)
    {
        
        document.write("*");
    }





